<?php
session_start();
include 'db.php'; // Database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $qualification = $_POST['qualification'];
    $address = $_POST['address'];

    // Handle profile image upload
    $profile_image = $_FILES['profile_image']['name'];
    $target = "uploads/" . basename($profile_image);

    if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $target)) {
        $sql = "INSERT INTO cashier (name, phone, email, qualification, address, profile_image) 
                VALUES ('$name', '$phone', '$email', '$qualification', '$address', '$profile_image')";
        if (mysqli_query($conn, $sql)) {
            echo "<script>alert('Cashier added successfully'); window.location.href='cashier_list.php';</script>";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Add Cashier</title>
    <link rel="stylesheet" href="addcashiers.css" />
</head>
<body>
    <div class="container">
        <h2>Add Cashier</h2>
        <form action="add_cashier.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required />
            </div>

            <div class="form-group">
                <label for="phone">Phone Number:</label>
                <input type="tel" id="phone" name="phone" pattern="[0-9]{10}" required />
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required />
            </div>

            <div class="form-group">
                <label for="qualification">Qualification:</label>
                <input type="text" id="qualification" name="qualification" required />
            </div>

            <div class="form-group">
                <label for="address">Address:</label>
                <input type="text" id="address" name="address" required />
            </div>

            <div class="form-group">
                <label for="profile_image">Profile Image:</label>
                <input type="file" id="profile_image" name="profile_image" />
            </div>

            <button type="submit" class="btn">Save</button>
            <a href="admin_dashboard.php" class="back-link">← Back to Dashboard</a>
        </form>
    </div>
</body>
</html>
