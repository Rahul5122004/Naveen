<?php
session_start();

if ($_SESSION['role'] !== 'Cashier') {
    header("Location: login.php");
    exit();
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Cashier Dashboard</title>
    <link rel="stylesheet" href="cashier_dashboard.css" />
</head>
<body>

<!-- Navigation Bar -->
<nav class="navbar">
    <div class="logo">🌟Retail Shop Billing System</div>
    <ul class="nav-links">
        <li><a href="billing.php">🧾Billing</a></li>
        <li class="dropdown">
            <a href="#">📦Products</a>
            <ul class="dropdown-content">
                <li><a href="view_product.php">📋View Products</a></li>
            </ul>
        </li>
        <li class="dropdown">
            <a href="#">👥Customers</a>
            <ul class="dropdown-content">
                <li><a href="add_customer.php">➕Add Customer</a></li>
                <li><a href="view_customer.php">📋View Customers</a></li>
            </ul>
        </li>
        <li><a href="logout.php" class="logout-btn">🚪Logout</a></li>
    </ul>
</nav>

<!-- Main Content -->
<div class="container">
    <h1>Welcome to Cashier Dashboard</h1>
    <p>Select an option from the navigation bar to proceed.</p>
</div>

</body>
</html>
