<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$user = $_SESSION['user'];
echo "<h2>Welcome, " . $user['username'] . "!</h2>";

if ($user['role'] === 'admin') {
    echo "<a href='admin.php'>Admin Panel</a>";
} elseif ($user['role'] === 'cashier') {
    echo "<a href='billing.php'>Billing</a>";
} else {
    echo "<a href='profile.php'>View Profile</a>";
}

echo "<br><a href='logout.php'>Logout</a>";
?>
