<?php
session_start();
include 'db.php';



$id = $_GET['id'];

// Fetch cashier details
$query = "SELECT * FROM cashiers WHERE id = '$id'";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);

if (isset($_POST['delete'])) {
    $deleteQuery = "DELETE FROM cashiers WHERE id = '$id'";
    if (mysqli_query($conn, $deleteQuery)) {
        echo "<script>alert('Cashier deleted successfully!'); window.location.href='cashier_list.php';</script>";
    } else {
        echo "<script>alert('Failed to delete cashier');</script>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Delete Cashier</title>
    <link rel="stylesheet" href="delete_cashier.css" />
</head>
<body>

<div class="form-container">
    <h2>Delete Cashier</h2>
    <p>Are you sure you want to delete this cashier?</p>

    <div class="cashier-details">
        <p><strong>ID:</strong> <?= $row['id'] ?></p>
        <p><strong>Username:</strong> <?= $row['username'] ?></p>
        <p><strong>Gender:</strong> <?= $row['gender'] ?></p>
        <p><strong>Address:</strong> <?= $row['address'] ?></p>
        <p><strong>Contact:</strong> <?= $row['contact'] ?></p>
    </div>

    <form method="POST">
        <div class="btn-group">
            <button type="submit" name="delete" class="btn-danger">Delete</button>
            <a href="cashier_list.php" class="btn-secondary">Cancel</a>
        </div>
    </form>
</div>

</body>
</html>
