<?php
session_start();
include 'db.php'; // Database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_code = $_POST['product_code'];
    $product_name = $_POST['product_name'];
    $price = $_POST['price'];
    $discount = $_POST['discount'];

    $sql = "INSERT INTO products (product_code, product_name, price, discount) 
            VALUES ('$product_code', '$product_name', '$price', '$discount')";

    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Product added successfully'); window.location.href='view_product.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
    <link rel="stylesheet" href="add_product.css">
</head>
<body>
<div class="container">
    <h2>Add Product</h2>
    <form action="" method="POST">
        <label>Product Code:</label>
        <input type="text" name="product_code" required>

        <label>Product Name:</label>
        <input type="text" name="product_name" required>

        <label>Price:</label>
        <input type="number" step="0.01" name="price" required>

        <label>Discount (%):</label>
        <input type="number" step="0.01" name="discount" value="0">

        <button type="submit">Add Product</button>
    </form>

    <!-- Back to Dashboard Button -->
    <a href="admin_dashboard.php" class="back-btn">⬅️ Back to Dashboard</a>
</div>
</body>
</html>
