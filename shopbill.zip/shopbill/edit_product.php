<?php
include 'db.php';



if (isset($_GET['product_code'])) {
    $product_code = $_GET['product_code'];

    // Fetch product details from the database
    $sql = "SELECT * FROM products WHERE product_code = '$product_code'";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $product = mysqli_fetch_assoc($result);
    } else {
        echo "<script>alert('Product not found!'); window.location.href='view_product.php';</script>";
        exit;
    }
}

// Update product details
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_code = $_POST['product_code'];
    $product_name = $_POST['product_name'];
    $price = $_POST['price'];
    $discount = $_POST['discount'];

    $update_query = "UPDATE products SET product_name='$product_name', price='$price', discount='$discount' WHERE product_code='$product_code'";
    if (mysqli_query($conn, $update_query)) {
        echo "<script>alert('Product updated successfully!'); window.location.href='view_product.php';</script>";
    } else {
        echo "Error updating product: " . mysqli_error($conn);
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <link rel="stylesheet" href="add_product.css">
</head>
<body>
<div class="container">
    <h2>Edit Product</h2>
    <form action="" method="POST">
        

        <label>Product Code:</label>
        <input type="number" step="0.01" name="product_code" value="<?= $product['product_code'] ?>" required>

        <label>Product Name:</label>
        <input type="text" name="product_name" value="<?= $product['product_name'] ?>" required>

        <label>Price:</label>
        <input type="number" step="0.01" name="price" value="<?= $product['price'] ?>" required>

        <label>Discount (%):</label>
        <input type="number" step="0.01" name="discount" value="<?= $product['discount'] ?>" required>

        <button type="submit" class="btn">Update Product</button>
        <a href="view_product.php" class="back-btn">← Back to Products</a>
    </form>
</div>
</body>
</html>
