<?php
include 'db.php'; // Database connection

// Check if 'id' is set in the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch cashier details
    $query = "SELECT * FROM cashiers WHERE id = '$id'";
    $result = mysqli_query($conn, $query);
    if ($result) {
        $row = mysqli_fetch_assoc($result);
    } else {
        echo "Error fetching record: " . mysqli_error($conn);
        exit;
    }
} else {
    echo "Invalid Request!";
    exit;
}

// Handle form submission
if (isset($_POST['update'])) {
    $username = $_POST['username'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];
    $password = $_POST['password'];

    // Hash the password before saving
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Update cashier details in the database
    $updateQuery = "UPDATE cashiers SET username='$username', password='$hashed_password', gender='$gender', address='$address', contact='$contact' WHERE id='$id'";
    if (mysqli_query($conn, $updateQuery)) {
        echo "<script>alert('Cashier updated successfully'); window.location.href='cashier_list.php';</script>";
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Edit Cashier</title>
    <link rel="stylesheet" href="edit_cashier.css" />

</head>
<body>

<div class="container">
    <h2>Edit Cashier</h2>
    <form method="POST" action="">
        <label for="username">Username:</label>
        <input type="text" name="username" value="<?php echo $row['username']; ?>" required />

        <label for="password">Password:</label>
        <div class="password-toggle">
            <input type="password" name="password" id="password" value="" placeholder="Enter new password" required />
            <span class="toggle-icon" onclick="togglePassword()">👁️</span>
        </div>

        <label for="gender">Gender:</label>
        <select name="gender" required>
            <option value="">Select Gender</option>
            <option value="Male" <?php if ($row['gender'] == 'Male') echo 'selected'; ?>>Male</option>
            <option value="Female" <?php if ($row['gender'] == 'Female') echo 'selected'; ?>>Female</option>
            <option value="Other" <?php if ($row['gender'] == 'Other') echo 'selected'; ?>>Other</option>
        </select>

        <label for="address">Address:</label>
        <input type="text" name="address" value="<?php echo $row['address']; ?>" required />

        <label for="contact">Contact:</label>
        <input type="text" name="contact" value="<?php echo $row['contact']; ?>" required />

        <div class="btn-container">
            <button type="submit" name="update" class="btn btn-update">Update</button>
            <a href="cashier_list.php" class="btn btn-back">Back</a>
        </div>
    </form>
</div>

<script>
    function togglePassword() {
        const passwordInput = document.getElementById('password');
        const icon = document.querySelector('.toggle-icon');

        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            icon.textContent = '🙈';
        } else {
            passwordInput.type = 'password';
            icon.textContent = '👁️';
        }
    }
</script>

</body>
</html>
