<?php
session_start();
include 'db.php';


$query = "SELECT * FROM cashiers";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Cashier List</title>
    <link rel="stylesheet" href="add_cashier.css" />
</head>
<body>

<div class="table-container">
    <h2>Cashier List</h2>
    <a href="add_cashier.php" class="btn-primary">➕ Add New Cashier</a>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Gender</th>
                <th>Address</th>
                <th>Contact</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= $row['username'] ?></td>
                <td><?= $row['gender'] ?></td>
                <td><?= $row['address'] ?></td>
                <td><?= $row['contact'] ?></td>
                <td>
    <a href="edit_cashier.php?id=<?= $row['id'] ?>" class="edit-btn">✏️ Edit</a>
    <a href="delete_cashier.php?id=<?= $row['id'] ?>" class="delete-btn" onclick="return confirm('Are you sure?')">❌ Delete</a>
</td>

            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

</body>
</html>
