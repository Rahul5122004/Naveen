<?php
include 'db.php'; // Database connection

// Handle delete request
if (isset($_GET['delete'])) {
    $product_code = $_GET['delete'];
    $sql = "DELETE FROM products WHERE product_code = '$product_code'";
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Product deleted successfully'); window.location.href='view_product.php';</script>";
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
}

$sql = "SELECT * FROM products";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Products</title>
    <link rel="stylesheet" href="view_product.css">
</head>
<body>

<div class="container">
    <h2>Product List</h2>
    
    <!-- Back and Add Buttons -->
    <div class="btn-container">
        <a href="admin_dashboard.php" href="cashier_dashboard.php" class="back-btn">⬅️ Back to Dashboard</a>
        <a href="add_product.php" class="add-btn">➕ Add New Product</a>
    </div>

    <table>
        <tr>
            <th>Product Code</th>
            <th>Product Name</th>
            <th>Price</th>
            <th>Discount</th>
            <th>Actions</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row['product_code'] ?></td>
                <td><?= $row['product_name'] ?></td>
                <td>₹<?= $row['price'] ?></td>
                <td><?= $row['discount'] ?>%</td>
                <td>
    <!-- Edit Button -->
    <a href="edit_product.php?product_code=<?= $row['product_code'] ?>" class="edit-btn">✏️ Edit</a>
    <!-- Delete Button -->
    <a href="view_product.php?delete=<?= $row['product_code'] ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this product?')">🗑️ Delete</a>
</td>

            </tr>
        <?php } ?>
    </table>
</div>

</body>
</html>
