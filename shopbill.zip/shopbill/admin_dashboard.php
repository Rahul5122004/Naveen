

<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'Admin') {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="admin_dashboard.css" />
</head>
<body>

<div class="navbar">
    <div class="logo">🌟 Retail Billing System</div>
    <div class="nav-links">
        <div class="dropdown">
            <button class="dropbtn">💼 Cashier</button>
            <div class="dropdown-content">
                <a href="add_cashier.php">➕ Add Cashier</a>
                <a href="edit_cashier.php">✏️ Edit Cashier</a>
                <a href="delete_cashier.php">❌ Delete Cashier</a>
                <a href="cashier_list.php">📋 Cashier List</a>
                

            </div>
        </div>

        <div class="dropdown">
            <button class="dropbtn">📦 Products</button>
            <div class="dropdown-content">
                <a href="add_product.php">➕ Add Product</a>
                <a href="view_product.php">📋 Product List</a>
            </div>
        </div>

        <div class="dropdown">
            <button class="dropbtn">💳 Transaction</button>
            <div class="dropdown-content">
                <a href="view_transaction.php">🔎 View Details</a>
            </div>
        </div>

        <div class="dropdown">
            <button class="dropbtn">👥 Customer</button>
            <div class="dropdown-content">
                <a href="customer_list.php">📋 Customer List</a>
            </div>
        </div>

        <div class="dropdown">
            <button class="dropbtn">📊 Report</button>
            <div class="dropdown-content">
                <a href="sales_report.php">📈 Sales Report</a>
            </div>
        </div>

        <a href="logout.php" class="logout-btn">🚪 Logout</a>
    </div>
</div>

<div class="content">
    <h2>Welcome, Admin! 🎉</h2>
    <p>Manage your system efficiently from here.</p>
</div>

</body>
</html>
