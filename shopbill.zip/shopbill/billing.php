<?php
include 'db.php';

if (isset($_GET['code'])) {
    $code = $_GET['code'];
    $sql = "SELECT * FROM products WHERE product_code = '$code'";
    $result = mysqli_query($conn, $sql);

    if ($row = mysqli_fetch_assoc($result)) {
        echo json_encode($row);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Billing</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>Billing Process</h2>
    <form id="billingForm">
        <label>Product Code:</label>
        <input type="text" id="product_code" onblur="getProductDetails()" required>

        <label>Product Name:</label>
        <input type="text" id="product_name" readonly>

        <label>Price:</label>
        <input type="number" id="price" readonly>

        <label>Quantity:</label>
        <input type="number" id="quantity" min="1" value="1" onchange="calculateTotal()">

        <label>Discount (%):</label>
        <input type="number" id="discount" readonly>

        <label>Total:</label>
        <input type="number" id="total" readonly>

        <button type="button" onclick="generateBill()">Generate Bill</button>
    </form>
</div>

<script>
    function getProductDetails() {
        var code = document.getElementById('product_code').value;
        if (code) {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'get_product.php?code=' + code, true);
            xhr.onload = function () {
                if (this.status == 200) {
                    var product = JSON.parse(this.responseText);
                    if (product) {
                        document.getElementById('product_name').value = product.product_name;
                        document.getElementById('price').value = product.price;
                        document.getElementById('discount').value = product.discount;
                        calculateTotal();
                    }
                }
            };
            xhr.send();
        }
    }

    function calculateTotal() {
        let price = parseFloat(document.getElementById('price').value) || 0;
        let discount = parseFloat(document.getElementById('discount').value) || 0;
        let quantity = parseInt(document.getElementById('quantity').value) || 1;

        let total = (price * quantity) * (1 - discount / 100);
        document.getElementById('total').value = total.toFixed(2);
    }

    function generateBill() {
        alert('Bill generated successfully!');
        // You can add PHP code to save the bill in the database here
    }
</script>
</body>
</html>
