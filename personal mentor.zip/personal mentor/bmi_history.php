<?php
session_start();
header('Content-Type: application/json');
require_once 'db_connect.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Please login first']);
    exit;
}

try {
    // Create bmi_history table if not exists
    $sql = "CREATE TABLE IF NOT EXISTS bmi_history (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        name VARCHAR(100) NOT NULL,
        weight FLOAT NOT NULL,
        height FLOAT NOT NULL,
        bmi FLOAT NOT NULL,
        category VARCHAR(50) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )";
    
    $conn->exec($sql);

    $method = $_SERVER['REQUEST_METHOD'];
    $user_id = $_SESSION['user_id'];

    switch ($method) {
        case 'GET':
            // Get BMI history for the user
            $stmt = $conn->prepare("SELECT * FROM bmi_history WHERE user_id = ? ORDER BY created_at DESC");
            $stmt->execute([$user_id]);
            $history = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['success' => true, 'data' => $history]);
            break;

        case 'POST':
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!isset($data['name']) || !isset($data['weight']) || !isset($data['height']) || !isset($data['bmi']) || !isset($data['category'])) {
                throw new Exception('Missing required fields');
            }
            
            // Add new BMI record
            $stmt = $conn->prepare("INSERT INTO bmi_history (user_id, name, weight, height, bmi, category) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $user_id,
                $data['name'],
                $data['weight'],
                $data['height'],
                $data['bmi'],
                $data['category']
            ]);
            
            echo json_encode(['success' => true, 'message' => 'BMI record added successfully']);
            break;

        case 'DELETE':
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!isset($data['id'])) {
                throw new Exception('Record ID is required');
            }
            
            // Delete BMI record
            $stmt = $conn->prepare("DELETE FROM bmi_history WHERE id = ? AND user_id = ?");
            $stmt->execute([$data['id'], $user_id]);
            
            if ($stmt->rowCount() > 0) {
                echo json_encode(['success' => true, 'message' => 'Record deleted successfully']);
            } else {
                throw new Exception('Record not found');
            }
            break;

        default:
            throw new Exception('Invalid request method');
    }
} catch(Exception $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
