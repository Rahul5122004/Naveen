<?php
header('Content-Type: application/json');
require_once '../db_connect.php';

try {
    $stmt = $conn->prepare("
        SELECT 
            id,
            name,
            email,
            mood,
            message,
            DATE_FORMAT(date, '%Y-%m-%d %H:%i:%s') as date
        FROM feedback 
        ORDER BY date DESC
    ");
    $stmt->execute();
    $feedback = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($feedback);
} catch(PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>
