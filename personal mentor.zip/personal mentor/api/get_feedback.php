<?php
header('Content-Type: application/json');
require_once '../db_connect.php';

try {
    $stmt = $conn->prepare("
        SELECT f.*, u.username 
        FROM feedback f 
        JOIN users u ON f.user_id = u.id 
        ORDER BY f.date DESC
    ");
    $stmt->execute();
    $feedback = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($feedback);
} catch(PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>
