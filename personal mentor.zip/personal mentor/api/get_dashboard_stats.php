<?php
header('Content-Type: application/json');
require_once '../db_connect.php';

try {
    // Get total users count
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM users");
    $stmt->execute();
    $total_users = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

    // Get total feedback count
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM feedback");
    $stmt->execute();
    $total_feedback = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

    echo json_encode([
        'total_users' => $total_users,
        'total_feedback' => $total_feedback
    ]);
} catch(PDOException $e) {
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
