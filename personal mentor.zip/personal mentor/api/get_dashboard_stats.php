<?php
header('Content-Type: application/json');
require_once '../db_connect.php';

try {
    // Get active users count (users who have logged in within the last 30 days)
    $stmt = $conn->prepare("
        SELECT COUNT(*) as count 
        FROM users 
        WHERE last_login >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    ");
    $stmt->execute();
    $active_users = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

    // Get total BMI records
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM bmi_records");
    $stmt->execute();
    $bmi_records = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

    // Get total feedback count
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM feedback");
    $stmt->execute();
    $feedback_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

    echo json_encode([
        'active_users' => $active_users,
        'bmi_records' => $bmi_records,
        'feedback_count' => $feedback_count
    ]);
} catch(PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>
