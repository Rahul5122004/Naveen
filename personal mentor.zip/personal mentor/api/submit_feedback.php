<?php
header('Content-Type: application/json');
require_once '../db_connect.php';

try {
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Validate input
    if (empty($data['name']) || empty($data['email']) || empty($data['message'])) {
        throw new Exception('Missing required fields');
    }

    // Insert feedback
    $stmt = $conn->prepare("
        INSERT INTO feedback (name, email, mood, message) 
        VALUES (?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $data['name'],
        $data['email'],
        $data['mood'],
        $data['message']
    ]);
    
    echo json_encode(['success' => true]);
} catch(Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>
