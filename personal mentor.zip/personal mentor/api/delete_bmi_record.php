<?php
header('Content-Type: application/json');
require_once '../db_connect.php';

try {
    $id = $_GET['id'];
    $stmt = $conn->prepare("DELETE FROM bmi_records WHERE id = ?");
    $stmt->execute([$id]);
    echo json_encode(['success' => true]);
} catch(PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>
