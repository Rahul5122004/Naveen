<?php
session_start();
header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Please login first']);
    exit;
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'personal_mentor');
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit;
}

// Create todos table if not exists
$sql = "CREATE TABLE IF NOT EXISTS todos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    category VARCHAR(50) NOT NULL,
    priority VARCHAR(20) NOT NULL,
    due_date DATE NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    progress INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
)";

$conn->query($sql);

// Handle different HTTP methods
$method = $_SERVER['REQUEST_METHOD'];
$user_id = $_SESSION['user_id'];

switch ($method) {
    case 'GET':
        // Get all todos for the user
        $sql = "SELECT * FROM todos WHERE user_id = ? ORDER BY created_at DESC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $todos = $result->fetch_all(MYSQLI_ASSOC);
        echo json_encode(['success' => true, 'data' => $todos]);
        break;

    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (isset($data['action'])) {
            switch ($data['action']) {
                case 'add':
                    // Add new todo
                    $sql = "INSERT INTO todos (user_id, title, category, priority, due_date, status, progress) 
                            VALUES (?, ?, ?, ?, ?, 'pending', 0)";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param('issss', 
                        $user_id,
                        $data['title'],
                        $data['category'],
                        $data['priority'],
                        $data['due_date']
                    );
                    
                    if ($stmt->execute()) {
                        $data['id'] = $stmt->insert_id;
                        echo json_encode(['success' => true, 'message' => 'Todo added successfully', 'data' => $data]);
                    } else {
                        echo json_encode(['success' => false, 'message' => 'Failed to add todo']);
                    }
                    break;

                case 'update':
                    // Update todo status or progress
                    $sql = "UPDATE todos SET status = ?, progress = ? WHERE id = ? AND user_id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param('siii', 
                        $data['status'],
                        $data['progress'],
                        $data['id'],
                        $user_id
                    );
                    
                    if ($stmt->execute()) {
                        echo json_encode(['success' => true, 'message' => 'Todo updated successfully']);
                    } else {
                        echo json_encode(['success' => false, 'message' => 'Failed to update todo']);
                    }
                    break;
            }
        }
        break;

    case 'DELETE':
        $data = json_decode(file_get_contents('php://input'), true);
        
        // Delete todo
        $sql = "DELETE FROM todos WHERE id = ? AND user_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ii', $data['id'], $user_id);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Todo deleted successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to delete todo']);
        }
        break;
}

$conn->close();
?>
