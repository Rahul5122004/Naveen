<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "personal_mentor";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]));
}

// Create transactions table if not exists
$sql = "CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type VARCHAR(10) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    category VARCHAR(50) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    notes TEXT,
    date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
)";

if ($conn->query($sql) === FALSE) {
    die(json_encode(['success' => false, 'message' => 'Error creating table: ' . $conn->error]));
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    die(json_encode(['success' => false, 'message' => 'Please sign in first']));
}

$user_id = $_SESSION['user_id'];

// Handle POST request (Add new transaction)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amount = $conn->real_escape_string($_POST['amount']);
    $type = $conn->real_escape_string($_POST['type']);
    $category = $conn->real_escape_string($_POST['category']);
    $payment_method = $conn->real_escape_string($_POST['payment_method']);
    $notes = $conn->real_escape_string($_POST['notes']);
    $date = date('Y-m-d'); // Current date

    $sql = "INSERT INTO transactions (user_id, type, amount, category, payment_method, notes, date) 
            VALUES ('$user_id', '$type', '$amount', '$category', '$payment_method', '$notes', '$date')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true, 'message' => 'Transaction added successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
    }
}

// Handle GET request (List transactions)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $sql = "SELECT * FROM transactions WHERE user_id = '$user_id' ORDER BY date DESC";
    $result = $conn->query($sql);

    $transactions = [];
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $transactions[] = [
                'id' => $row['id'],
                'type' => $row['type'],
                'amount' => $row['amount'],
                'category' => $row['category'],
                'payment_method' => $row['payment_method'],
                'notes' => $row['notes'],
                'date' => $row['date']
            ];
        }
    }

    echo json_encode(['success' => true, 'data' => $transactions]);
}

// Handle DELETE request
if ($_SERVER['REQUEST_METHOD'] === 'DELETE' && isset($_GET['id'])) {
    $id = $conn->real_escape_string($_GET['id']);
    
    $sql = "DELETE FROM transactions WHERE id = '$id' AND user_id = '$user_id'";
    
    if ($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true, 'message' => 'Transaction deleted successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error deleting transaction']);
    }
}

$conn->close();
?>
