<?php
require_once '../config/db_connect.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $type = $_POST['type'];
    $amount = floatval($_POST['amount']);
    $category = $_POST['category'];
    $description = $_POST['description'];

    $stmt = $conn->prepare("INSERT INTO transactions (user_id, type, amount, category, description) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("isdss", $user_id, $type, $amount, $category, $description);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Transaction saved successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error saving transaction']);
    }
    $stmt->close();
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $user_id = $_SESSION['user_id'];
    $result = $conn->query("SELECT * FROM transactions WHERE user_id = $user_id ORDER BY date DESC");
    $transactions = [];
    while ($row = $result->fetch_assoc()) {
        $transactions[] = $row;
    }
    echo json_encode(['success' => true, 'data' => $transactions]);
}
?>
