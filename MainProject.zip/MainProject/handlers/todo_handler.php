<?php
require_once '../config/db_connect.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $due_date = $_POST['due_date'] ?? null;

    $stmt = $conn->prepare("INSERT INTO todos (user_id, title, description, due_date) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $user_id, $title, $description, $due_date);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Todo added successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error adding todo']);
    }
    $stmt->close();
}

if ($_SERVER["REQUEST_METHOD"] == "PUT") {
    $_PUT = json_decode(file_get_contents('php://input'), true);
    $todo_id = $_PUT['todo_id'];
    $status = $_PUT['status'];
    $user_id = $_SESSION['user_id'];

    $stmt = $conn->prepare("UPDATE todos SET status = ? WHERE todo_id = ? AND user_id = ?");
    $stmt->bind_param("sii", $status, $todo_id, $user_id);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Todo updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error updating todo']);
    }
    $stmt->close();
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $user_id = $_SESSION['user_id'];
    $result = $conn->query("SELECT * FROM todos WHERE user_id = $user_id ORDER BY created_at DESC");
    $todos = [];
    while ($row = $result->fetch_assoc()) {
        $todos[] = $row;
    }
    echo json_encode(['success' => true, 'data' => $todos]);
}
?>
