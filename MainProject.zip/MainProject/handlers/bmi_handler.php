<?php
require_once '../config/db_connect.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $weight = floatval($_POST['weight']);
    $height = floatval($_POST['height']);
    $bmi = $weight / ($height * $height);

    $stmt = $conn->prepare("INSERT INTO bmi_records (user_id, weight, height, bmi) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iddd", $user_id, $weight, $height, $bmi);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'BMI record saved successfully', 'bmi' => $bmi]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error saving BMI record']);
    }
    $stmt->close();
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $user_id = $_SESSION['user_id'];
    $result = $conn->query("SELECT * FROM bmi_records WHERE user_id = $user_id ORDER BY date DESC");
    $records = [];
    while ($row = $result->fetch_assoc()) {
        $records[] = $row;
    }
    echo json_encode(['success' => true, 'data' => $records]);
}
?>
