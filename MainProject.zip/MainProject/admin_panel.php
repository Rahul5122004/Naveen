<?php
session_start();
require_once 'config/db_connect.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.html');
    exit;
}

// Get statistics
$stats = [];

// Total registered users
$query = "SELECT COUNT(*) as total FROM users";
$result = mysqli_query($conn, $query);
$stats['total_users'] = mysqli_fetch_assoc($result)['total'];

// Active users (logged in within last 24 hours)
$query = "SELECT COUNT(*) as active FROM users WHERE last_login >= NOW() - INTERVAL 24 HOUR";
$result = mysqli_query($conn, $query);
$stats['active_users'] = mysqli_fetch_assoc($result)['active'];

// Total mentors
$query = "SELECT COUNT(*) as total FROM mentors";
$result = mysqli_query($conn, $query);
$stats['total_mentors'] = mysqli_fetch_assoc($result)['total'];

// Average feedback rating
$query = "SELECT AVG(rating) as avg_rating FROM feedback";
$result = mysqli_query($conn, $query);
$stats['avg_rating'] = number_format(mysqli_fetch_assoc($result)['avg_rating'], 1);

// Recent feedback
$query = "SELECT * FROM feedback ORDER BY created_at DESC LIMIT 5";
$recent_feedback = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Personal Mentor</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2ecc71;
            --secondary-color: #27ae60;
            --bg-dark: #1a1c20;
            --bg-light: #2d3436;
            --text-light: #ffffff;
            --text-dark: #333333;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, var(--bg-dark) 0%, var(--bg-light) 100%);
            color: var(--text-light);
            min-height: 100vh;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background: rgba(0, 0, 0, 0.2);
            padding: 20px;
            backdrop-filter: blur(10px);
        }

        .logo {
            text-align: center;
            padding: 20px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
        }

        .nav-menu {
            margin-top: 30px;
        }

        .nav-item {
            padding: 12px 15px;
            margin: 5px 0;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
        }

        .nav-item i {
            margin-right: 10px;
            width: 20px;
        }

        .nav-item:hover {
            background: var(--primary-color);
        }

        .nav-item.active {
            background: var(--primary-color);
        }

        /* Main Content Styles */
        .main-content {
            flex: 1;
            padding: 20px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            margin-bottom: 30px;
        }

        .search-bar {
            display: flex;
            align-items: center;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 5px 15px;
        }

        .search-bar input {
            background: none;
            border: none;
            color: var(--text-light);
            padding: 8px;
            outline: none;
            width: 200px;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .card {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 20px;
            backdrop-filter: blur(10px);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .card-icon {
            background: var(--primary-color);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .card-title {
            font-size: 1.1em;
            margin-bottom: 5px;
        }

        .card-value {
            font-size: 1.8em;
            font-weight: bold;
        }

        .recent-activity {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 20px;
            backdrop-filter: blur(10px);
        }

        .activity-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .activity-list {
            list-style: none;
        }

        .activity-item {
            display: flex;
            align-items: center;
            padding: 15px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .activity-icon {
            margin-right: 15px;
            width: 40px;
            height: 40px;
            background: var(--primary-color);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .btn {
            background: var(--primary-color);
            color: var(--text-light);
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s;
        }

        .btn:hover {
            background: var(--secondary-color);
        }

        #content-area {
            margin-top: 20px;
        }

        /* Add new styles for feedback section */
        .feedback-list {
            margin-top: 30px;
        }

        .feedback-item {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            backdrop-filter: blur(10px);
        }

        .feedback-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .feedback-rating {
            color: #2ecc71;
        }

        .feedback-rating i {
            color: #f1c40f;
        }

        .feedback-message {
            color: #fff;
            line-height: 1.5;
        }

        .feedback-meta {
            color: rgba(255, 255, 255, 0.6);
            font-size: 0.9em;
            margin-top: 10px;
        }

        .stat-trend {
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 0.9em;
        }

        .trend-up {
            color: #2ecc71;
        }

        .trend-down {
            color: #e74c3c;
        }

        .chart-container {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 20px;
            margin-top: 20px;
            height: 300px;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <img src="images/s.jpeg" alt="Logo">
                <h3>Personal Mentor</h3>
            </div>
            <nav class="nav-menu">
                <div class="nav-item active" data-page="dashboard">
                    <i class="fas fa-home"></i>
                    Dashboard
                </div>
                <div class="nav-item" data-page="users">
                    <i class="fas fa-users"></i>
                    Users
                </div>
                <div class="nav-item" data-page="mentors">
                    <i class="fas fa-chalkboard-teacher"></i>
                    Mentors
                </div>
                <div class="nav-item" data-page="feedback">
                    <i class="fas fa-comments"></i>
                    Feedback
                </div>
                <div class="nav-item" data-page="reports">
                    <i class="fas fa-chart-bar"></i>
                    Reports
                </div>
                <div class="nav-item" data-page="settings">
                    <i class="fas fa-cog"></i>
                    Settings
                </div>
                <div class="nav-item" id="logout">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </div>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <div class="search-bar">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search...">
                </div>
                <div class="user-profile">
                    <span><?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                    <i class="fas fa-user-circle"></i>
                </div>
            </div>

            <div id="content-area">
                <!-- Dashboard Content -->
                <div class="dashboard-cards">
                    <div class="card">
                        <div class="card-header">
                            <div class="card-icon">
                                <i class="fas fa-users"></i>
                            </div>
                        </div>
                        <div class="card-title">Total Users</div>
                        <div class="card-value"><?php echo $stats['total_users']; ?></div>
                        <div class="stat-trend trend-up">
                            <i class="fas fa-arrow-up"></i>
                            <span>12% this week</span>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <div class="card-icon">
                                <i class="fas fa-user-clock"></i>
                            </div>
                        </div>
                        <div class="card-title">Active Users (24h)</div>
                        <div class="card-value"><?php echo $stats['active_users']; ?></div>
                        <div class="stat-trend trend-up">
                            <i class="fas fa-arrow-up"></i>
                            <span>8% today</span>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <div class="card-icon">
                                <i class="fas fa-chalkboard-teacher"></i>
                            </div>
                        </div>
                        <div class="card-title">Total Mentors</div>
                        <div class="card-value"><?php echo $stats['total_mentors']; ?></div>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <div class="card-icon">
                                <i class="fas fa-star"></i>
                            </div>
                        </div>
                        <div class="card-title">Average Rating</div>
                        <div class="card-value"><?php echo $stats['avg_rating']; ?></div>
                        <div class="stat-trend trend-up">
                            <i class="fas fa-arrow-up"></i>
                            <span>0.2 this month</span>
                        </div>
                    </div>
                </div>

                <!-- Recent Feedback -->
                <div class="recent-activity">
                    <div class="activity-header">
                        <h3>Recent Feedback</h3>
                        <button class="btn" onclick="loadAllFeedback()">View All</button>
                    </div>
                    <div class="feedback-list">
                        <?php while ($feedback = mysqli_fetch_assoc($recent_feedback)): ?>
                        <div class="feedback-item">
                            <div class="feedback-header">
                                <strong><?php echo htmlspecialchars($feedback['name']); ?></strong>
                                <div class="feedback-rating">
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <i class="fas fa-star" style="color: <?php echo $i <= $feedback['rating'] ? '#f1c40f' : '#666'; ?>"></i>
                                    <?php endfor; ?>
                                </div>
                            </div>
                            <div class="feedback-message">
                                <?php echo htmlspecialchars($feedback['message']); ?>
                            </div>
                            <div class="feedback-meta">
                                Submitted on <?php echo date('M d, Y H:i', strtotime($feedback['created_at'])); ?>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    </div>
                </div>

                <!-- User Activity Chart -->
                <div class="chart-container">
                    <canvas id="userActivityChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // User Activity Chart
        const ctx = document.getElementById('userActivityChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                    label: 'Active Users',
                    data: [65, 59, 80, 81, 56, 55, 40],
                    borderColor: '#2ecc71',
                    tension: 0.4,
                    fill: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: {
                            color: '#fff'
                        }
                    }
                },
                scales: {
                    y: {
                        ticks: {
                            color: '#fff'
                        },
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        }
                    },
                    x: {
                        ticks: {
                            color: '#fff'
                        },
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        }
                    }
                }
            }
        });

        // Navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', function() {
                if (this.id === 'logout') {
                    window.location.href = 'logout.php';
                    return;
                }

                document.querySelectorAll('.nav-item').forEach(navItem => {
                    navItem.classList.remove('active');
                });
                this.classList.add('active');

                const page = this.getAttribute('data-page');
                loadContent(page);
            });
        });

        function loadContent(page) {
            // Handle page loading via AJAX
            console.log(`Loading ${page} content...`);
        }

        function loadAllFeedback() {
            // Implement view all feedback functionality
            console.log('Loading all feedback...');
        }
    </script>
</body>
</html>
