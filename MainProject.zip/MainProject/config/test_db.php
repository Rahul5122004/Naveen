<?php
require_once 'db_connect.php';

// Test query
$query = "SELECT 1";
$result = mysqli_query($conn, $query);

if ($result) {
    echo "Database connection successful!";
} else {
    echo "Database error: " . mysqli_error($conn);
}
?>
