<?php
session_start();

$servername = "localhost"; // Changed from localhost:3306 to just localhost
$username = "root";  // Default XAMPP username
$password = "";  // Default XAMPP password
$dbname = "personal_mentor";  // Your database name

// Create connection with performance settings
$conn = new mysqli($servername, $username, $password, $dbname);

// Set charset to utf8mb4 for better performance
$conn->set_charset("utf8mb4");

// Enable autocommit for better performance in this application
$conn->autocommit(TRUE);

// Check connection
if ($conn->connect_error) {
    error_log("Connection failed: " . $conn->connect_error);  // Log error
    die(json_encode(['success' => false, 'message' => 'Database connection failed']));
}
?>
