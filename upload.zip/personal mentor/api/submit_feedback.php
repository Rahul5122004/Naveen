<?php
header('Content-Type: application/json');
require_once '../db_connect.php';

try {
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Validate input
    if (empty($data['name']) || empty($data['email']) || empty($data['message']) || empty($data['mood'])) {
        throw new Exception('Missing required fields');
    }

    // Insert feedback
    $stmt = $conn->prepare("
        INSERT INTO feedback (name, email, mood, message, date) 
        VALUES (?, ?, ?, ?, NOW())
    ");
    
    $stmt->execute([
        $data['name'],
        $data['email'],
        $data['mood'],
        $data['message']
    ]);
    
    $feedbackId = $conn->lastInsertId();
    
    // Get the inserted feedback to return
    $stmt = $conn->prepare("
        SELECT 
            id,
            name,
            email,
            mood,
            message,
            DATE_FORMAT(date, '%Y-%m-%d %H:%i:%s') as date
        FROM feedback 
        WHERE id = ?
    ");
    $stmt->execute([$feedbackId]);
    $feedback = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'message' => 'Feedback submitted successfully',
        'feedback' => $feedback
    ]);
} catch(Exception $e) {
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
