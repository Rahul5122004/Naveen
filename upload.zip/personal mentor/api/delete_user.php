<?php
header('Content-Type: application/json');
require_once '../db_connect.php';

try {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['id'])) {
        throw new Exception('User ID is required');
    }

    // Start transaction
    $conn->beginTransaction();

    // Delete user's feedback first
    $stmt = $conn->prepare("DELETE FROM feedback WHERE email = (SELECT email FROM users WHERE id = ?)");
    $stmt->execute([$data['id']]);

    // Then delete the user
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$data['id']]);

    if ($stmt->rowCount() > 0) {
        $conn->commit();
        echo json_encode(['success' => true, 'message' => 'User and associated feedback deleted successfully']);
    } else {
        throw new Exception('User not found');
    }
} catch(Exception $e) {
    if ($conn->inTransaction()) {
        $conn->rollBack();
    }
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
