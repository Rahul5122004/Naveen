<?php
session_start();
header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Please login first']);
    exit;
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'personal_mentor');
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit;
}

// Create bmi_history table if not exists
$sql = "CREATE TABLE IF NOT EXISTS bmi_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    weight FLOAT NOT NULL,
    height FLOAT NOT NULL,
    bmi FLOAT NOT NULL,
    category VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
)";

$conn->query($sql);

$method = $_SERVER['REQUEST_METHOD'];
$user_id = $_SESSION['user_id'];

switch ($method) {
    case 'GET':
        // Get BMI history for the user with user's name
        $sql = "SELECT bh.*, u.fullname FROM bmi_history bh 
                JOIN users u ON bh.user_id = u.id 
                WHERE bh.user_id = ? 
                ORDER BY bh.created_at DESC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $history = $result->fetch_all(MYSQLI_ASSOC);
        echo json_encode(['success' => true, 'data' => $history]);
        break;

    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);
        
        // Add new BMI record
        $sql = "INSERT INTO bmi_history (user_id, weight, height, bmi, category) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('iddds', 
            $user_id,
            $data['weight'],
            $data['height'],
            $data['bmi'],
            $data['category']
        );
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'BMI record added successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to add BMI record']);
        }
        break;

    case 'DELETE':
        $data = json_decode(file_get_contents('php://input'), true);
        
        // Delete BMI record
        $sql = "DELETE FROM bmi_history WHERE id = ? AND user_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ii', $data['id'], $user_id);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Record deleted successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to delete record']);
        }
        break;
}

$conn->close();
?>
